import web

urls = (
    '/', 'controllers.index.Index',
    '/fila', 'controllers.fila.Fila',
    '/agregar_estudiante', 'controllers.agregar_estudiante.AgregarEstudiante',
    '/atender_estudiante', 'controllers.atender_estudiante.AtenderEstudiante',
)
app = web.application(urls, globals())

if __name__ == "__main__":
    app.run()
