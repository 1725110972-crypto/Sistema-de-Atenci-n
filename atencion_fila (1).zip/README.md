# Sistema de Atencion - Servicios Escolares (Cola FIFO)

Ejercicio del 16 de septiembre (Rigoberto). Simula la ventanilla de
servicios escolares con una **fila (Cola)**: el estudiante que llega
primero, es el primero en ser atendido (FIFO - Primeras Entradas,
Primeras Salidas).

Misma estructura que el proyecto de "Productos del Supermercado
(Aurrera)": web.py + controllers + views, pero el TDA aqui es una
**Cola**, no una lista ordenada.

## Estructura

```
atencion_fila/
├── app.py                          # rutas
├── controllers/
│   ├── estado.py                    # la instancia unica de la Cola, compartida
│   ├── index.py
│   ├── fila.py                      # mostrar fila, siguiente, cantidad, alerta de vacia
│   ├── agregar_estudiante.py        # formulario + encolar
│   └── atender_estudiante.py        # desencolar (atender al del frente)
├── tda/
│   └── cola.py                      # el TDA: Cola (FIFO)
├── temporal/
│   └── app.py                       # copia de referencia
└── views/
    ├── layout.html
    ├── index.html
    ├── fila.html
    ├── agregar_estudiante.html
    └── atender_estudiante.html
```

## Operaciones pedidas -> donde estan implementadas

| Operacion pedida | Donde |
|---|---|
| a) Agregar un estudiante a la fila | `controllers/agregar_estudiante.py` -> `Cola.encolar()` |
| b) Atender al estudiante del frente | `controllers/atender_estudiante.py` -> `Cola.desencolar()` |
| c) Consultar quien es el siguiente | `controllers/fila.py` -> `Cola.frente()` (se muestra en `/fila`) |
| d) Mostrar todos los que esperan | `controllers/fila.py` -> `Cola.obtener_todos()` |
| e) Cuantos estudiantes estan esperando | `controllers/fila.py` -> `Cola.tamano()` |
| f) Avisar si la fila esta vacia | `Cola.esta_vacia()`, usado en `/fila` (alerta) y en `/atender_estudiante` |

## Manejo de duplicados

Si agregas una matricula que ya esta en la fila, **no se crea una fila
nueva**: el nuevo tramite se agrega a la MISMA celda del estudiante que
ya existia (por ejemplo, "Constancia, Titulo"), sin repetir el mismo
tramite dos veces, y sin mover al estudiante de su posicion. Ademas se
muestra un aviso en `/fila` avisando que esa matricula ya estaba
registrada. Esto vive en `controllers/agregar_estudiante.py`
(`Cola.buscar()` y `Cola.posicion_de()` en `tda/cola.py`).

## Datos del estudiante

- Matricula
- Nombre
- Carrera
- Tipo de tramite

## Por que no hay base de datos aqui

A diferencia del proyecto de Aurrera, esta fila es informacion
**transitoria**: un estudiante entra, se atiende, y desaparece de la
fila para siempre (no hay "historial" que consultar despues, como si
pedian los requisitos). Por eso el TDA vive en memoria mientras el
servidor esta corriendo (ver `controllers/estado.py`), sin necesidad de
SQLite. Si se pidiera un reporte de "todos los estudiantes atendidos en
el dia", ahi si tendria sentido agregar una base de datos para guardar
ese historial.

## Notas de compatibilidad (Codespaces / Python 3.13+)

- `requirements.txt` pide `web.py>=0.76` y no una version vieja fija
  (como 0.62), porque las versiones viejas de web.py necesitan el
  modulo `cgi`, que Python 3.13+ ya no trae incluido. La version 0.76+
  ya no depende de `cgi`.
- Los redirects (`/agregar_estudiante` -> `/fila`) se hacen escribiendo
  el header `Location` a mano con una ruta RELATIVA
  (`web.header('Location', '/fila')`), en vez de usar
  `web.seeother('/fila')`. Esto evita un bug donde, dentro de
  Codespaces, `web.seeother` arma la URL completa usando el host que ve
  el servidor por dentro (`localhost`), sacandote de la URL publica
  (`...app.github.dev`).

## Como correrlo

```bash
pip install -r requirements.txt
python3 app.py
```

Entra a `/fila` para ver la fila. Desde ahi puedes agregar estudiantes
y atender al que esta al frente.
