# -*- coding: utf-8 -*-
"""
TDA: Cola (FIFO - Primeras Entradas, Primeras Salidas)
--------------------------------------------------------
El estudiante que llega primero a la ventanilla es el primero en ser
atendido. Quien se agrega, se agrega siempre al FINAL de la fila; quien
se atiende, se quita siempre del FRENTE de la fila. Nunca se inserta ni
se atiende en medio, a diferencia de la lista ordenada del proyecto
anterior.
"""


class Cola:
    def __init__(self):
        self._datos = []

    def __len__(self):
        return len(self._datos)

    def encolar(self, elemento):
        """Agrega un elemento al FINAL de la fila."""
        self._datos.append(elemento)

    def desencolar(self):
        """
        Quita y regresa el elemento del FRENTE de la fila (el que
        lleva mas tiempo esperando). Si la fila esta vacia, regresa None.
        """
        if self.esta_vacia():
            return None
        return self._datos.pop(0)

    def frente(self):
        """Consulta quien es el siguiente, SIN quitarlo de la fila."""
        if self.esta_vacia():
            return None
        return self._datos[0]

    def esta_vacia(self):
        return len(self._datos) == 0

    def tamano(self):
        return len(self._datos)

    def obtener_todos(self):
        """Regresa la fila completa, en orden de llegada."""
        return list(self._datos)

    def buscar(self, predicado):
        """
        Regresa el PRIMER elemento (la referencia real, no una copia) para
        el cual predicado(elemento) sea verdadero, o None si no hay ninguno.
        Como es la referencia real, modificar el diccionario que regresa
        SI afecta a la fila, sin cambiar su posicion.
        """
        for elemento in self._datos:
            if predicado(elemento):
                return elemento
        return None

    def posicion_de(self, predicado):
        """
        Regresa la posicion (empezando en 1) del primer elemento que
        cumple predicado, o None si no esta en la fila.
        """
        for i, elemento in enumerate(self._datos, start=1):
            if predicado(elemento):
                return i
        return None
