import web

from controllers.estado import fila_estudiantes

render = web.template.render('views', base='layout')


class Fila:
    def GET(self):
        entrada = web.input(duplicado='', matricula='')

        estudiantes = fila_estudiantes.obtener_todos()
        siguiente = fila_estudiantes.frente()
        cantidad = fila_estudiantes.tamano()
        vacia = fila_estudiantes.esta_vacia()

        return render.fila(
            estudiantes, siguiente, cantidad, vacia,
            entrada.duplicado, entrada.matricula,
        )
