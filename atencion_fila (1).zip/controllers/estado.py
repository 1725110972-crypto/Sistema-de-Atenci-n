# -*- coding: utf-8 -*-
"""
Una sola instancia de la Cola, compartida por todos los controllers.
Mientras el servidor este corriendo, todos leen y modifican esta misma
fila (por eso "agregar_estudiante" y "atender_estudiante" ven los
cambios del otro).
"""
from tda.cola import Cola

fila_estudiantes = Cola()
