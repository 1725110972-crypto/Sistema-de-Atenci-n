import web
from urllib.parse import quote

from controllers.estado import fila_estudiantes

render = web.template.render('views', base='layout')


class AgregarEstudiante:
    def GET(self):
        return render.agregar_estudiante(None)

    def POST(self):
        entrada = web.input(matricula='', nombre='', carrera='', tipo_tramite='')

        matricula = entrada.matricula.strip()
        nombre = entrada.nombre.strip()
        carrera = entrada.carrera.strip()
        tipo_tramite = entrada.tipo_tramite.strip()

        if not matricula or not nombre:
            return render.agregar_estudiante(
                "Matricula y nombre son obligatorios. No se agrego a la fila."
            )

        # Si la matricula ya esta en la fila, NO se duplica: se agrega el
        # nuevo tramite EN LA MISMA CELDA del estudiante que ya existe,
        # en su misma posicion, en vez de crear una fila nueva abajo.
        estudiante_existente = fila_estudiantes.buscar(
            lambda e: e['matricula'] == matricula
        )

        if estudiante_existente:
            tramites_actuales = [
                t.strip() for t in estudiante_existente['tipo_tramite'].split(',') if t.strip()
            ]
            if tipo_tramite and tipo_tramite not in tramites_actuales:
                tramites_actuales.append(tipo_tramite)
            estudiante_existente['tipo_tramite'] = ', '.join(tramites_actuales)

            if carrera:
                estudiante_existente['carrera'] = carrera

            # Redirect con aviso: la vista /fila muestra el mensaje de
            # "ya estaba en la fila, no se duplico".
            web.ctx.status = '303 See Other'
            web.header('Location', f'/fila?duplicado=1&matricula={quote(matricula)}')
            return ''

        estudiante = {
            'matricula': matricula,
            'nombre': nombre,
            'carrera': carrera,
            'tipo_tramite': tipo_tramite,
        }
        fila_estudiantes.encolar(estudiante)

        # Redirect RELATIVO a mano: si usaramos web.seeother('/fila'),
        # web.py arma la URL completa con el host que ve el servidor por
        # dentro (localhost), y en Codespaces eso te saca de la URL
        # publica (...app.github.dev). Con Location='/fila' el navegador
        # resuelve la ruta contra la URL en la que ya estas, sin importar
        # cual sea el dominio.
        web.ctx.status = '303 See Other'
        web.header('Location', '/fila')
        return ''
