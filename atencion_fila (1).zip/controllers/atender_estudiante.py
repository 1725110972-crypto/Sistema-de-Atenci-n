import web

from controllers.estado import fila_estudiantes

render = web.template.render('views', base='layout')


class AtenderEstudiante:
    def GET(self):
        atendido = fila_estudiantes.desencolar()
        return render.atender_estudiante(atendido)
